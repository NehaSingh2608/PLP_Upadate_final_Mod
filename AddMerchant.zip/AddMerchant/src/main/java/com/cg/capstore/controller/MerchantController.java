package com.cg.capstore.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.MerchantAlreadyExist;
import com.cg.capstore.service.IMerchantService;



@Controller
public class MerchantController {

	@Autowired
	IMerchantService service;
	String id;
	
	
	@RequestMapping(value="/")
	public String hello() {
		System.out.println("gbjhfjkdgjfg");
		return "/pages/registerMerchant.jsp";
	}
	
	@RequestMapping(value="/addresspage")
	public String addAddress(@Valid @ModelAttribute("merchant") Merchant merchant) throws MerchantAlreadyExist  {
		
		 service.registerMerchant(merchant);
		 id=merchant.getMerchantMobileNo();
		 return "/pages/addresspage.jsp";}

	@RequestMapping( value = "/success")
	public String registered(@Valid @ModelAttribute("address") Address address){
		service.addAddress(address,id);
		 return "/pages/sucess.jsp";
	}
	
}
